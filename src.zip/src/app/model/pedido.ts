export class Pedido {}
